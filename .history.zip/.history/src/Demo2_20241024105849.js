import React from 'react'

const Demo2 = () => {
  return (
    <div>Demo2</div>
  )
}

export default Demo2