import React from 'react'

const Demo2 = () => {
    return (
        <div className='container'>
                <div class="row mb-2">
                    <div>
                        <label className='text-start'>Email</label>
                   
                        <input type="email" className='col-6' placeholder="Email" />
                    </div>
                    <div>
                        <label className=' text-start'>Email</label>
            
                        <input type="email" className='form-control' placeholder="Email" />
                    </div>
                </div>
        </div>
    )
}

export default Demo2