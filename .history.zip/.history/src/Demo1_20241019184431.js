import React from 'react'

const Demo1 = () => {
  return (
    <div className='container'>
     <div className='row'>
         <div className='col-6' style={{backgroundColor:'skyblue'}}>1</div>
         <div className='col-4' style={{backgroundColor:'skyblue'}}>1</div>
         <div className='col-2' style={{backgroundColor:'skyblue'}}>1</div>
     </div>
    </div>
  )
}

export default Demo1