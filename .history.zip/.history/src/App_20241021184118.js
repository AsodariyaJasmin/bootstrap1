// import { Provider } from 'react-redux';
import './App.css';
import Demo1 from './Demo1';
// import store from './Redux/store';

function App() {
  return (
    <div className="App">
      {/* <Provider store={store}> */}
      <Demo1/>
      {/* </Provider> */}
    </div>
  );
}

export default App;
