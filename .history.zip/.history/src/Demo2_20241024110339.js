import React from 'react'

const Demo2 = () => {
    return (
        <div className='container'>

            <div className='row'>
                <div>
                    <label className='col-12'>First Name:</label>
                </div>
                <div>
                    <input type='text' className='col'></input>
                </div>
            </div>
        </div>
    )
}

export default Demo2