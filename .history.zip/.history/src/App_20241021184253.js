// import { Provider } from 'react-redux';
import './App.css';
import Demo1 from './Demo1';
// import store from './Redux/store';

function App() {
  return (
    <div className="App">
      <Demo1/>
    </div>
  );
}

export default App;
