import React from 'react'

const Demo1 = () => {
  return (
    <div className='container'>
     <div className='row'>
         <div className='col' style={{backgroundColor:'skyblue'}}>1</div>
         <div className='col'>1</div>
         <div className='col'>1</div>
     </div>
    </div>
  )
}

export default Demo1