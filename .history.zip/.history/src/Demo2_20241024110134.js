import React from 'react'

const Demo2 = () => {
  return (
    <div className='container'>

      <div className='row'>
        <label className='col-12'>First Name:</label>
        <input type='text' className='col-12'></input>
      </div>
    </div>
  )
}

export default Demo2