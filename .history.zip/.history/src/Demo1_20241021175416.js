import React from 'react'

const Demo1 = () => {
  return (
    <div className='container'>
     <div className='row'>
         <div className='col-6 text-danger' >1</div>
         <div className='col-4 bg-green'>1</div>
         <div className='col-2' style={{backgroundColor:'black'}}>1</div>
     </div>
    </div>
  )
}

export default Demo1